# CSS Exercise

Work through the **index.html** file and apply the required styles in the CSS file